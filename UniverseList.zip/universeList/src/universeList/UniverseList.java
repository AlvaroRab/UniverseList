package universeList;

import java.util.AbstractList;
import java.util.Collection;
import java.util.NoSuchElementException;

public class UniverseList<E>{
	
	private E[] data;
	
	private int current;
	
	public UniverseList() {
		data = (E[]) new Object[10];
		
		current = 0;
	}
	
	public UniverseList(Collection <? extends E> c) {
		data = (E[]) new Object[c.size()];
		
		int i = 0;
		for(E element: c) {
			add(i,element);
			i++;
		}
		current = 0;
	}
	
	
	public int size() {
		return data.length;
	}

	
	public E get(int index) {
		throw new UnsupportedOperationException();
	}
	
	public E get() {
		if(current >= data.length) return null;
		return data[current];
	}
	
	public void add(int index, E element) {
		if(index < current) throw new IndexOutOfBoundsException();

		ensureCapacity(index);
		if(data[index] !=null) throw new IllegalArgumentException();
		
		data[index] = element;
		
		
	}
	
	public E next() {
		if (current >= data.length) {
            throw new NoSuchElementException("No hay más elementos en el universo");
        }
        
        E element = data[current];
        data[current] = null;
        current++;
        
        return element;
	}
	 	
	
	private void ensureCapacity(int index) {
		
		if(index >= data.length) {
			int newCapacity = Math.max(data.length * 2, index + 1);
			E[] newData = (E[]) new Object[newCapacity];
			for(int i = 0; i <  data.length;i++) {
				newData[i] = data[i];
			}
			data = newData;
		}
	}

}
